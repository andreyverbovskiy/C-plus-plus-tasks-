#include "Imutex.h"
#include <mutex>
#include <ctime>
class RealTimeClock {
public:
	RealTimeClock(const tm *time ,int ticksPerSecond);
	RealTimeClock(int ticksPerSecond);
	void gettime(tm *now);
	~RealTimeClock() {}
	void tick();
private:
	volatile int hour;
	volatile int min;
	volatile int sec;
	int ticksPerSecond; // 1000
	int tickCounter; // when tick called increment by 1
	Imutex guard;
};
