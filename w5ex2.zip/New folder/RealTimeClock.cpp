#include "RealTimeClock.h"

RealTimeClock::RealTimeClock(int ticksPerSecond):ticksPerSecond(ticksPerSecond){
	hour=23;
	min=58;
	sec=35;
}

RealTimeClock::RealTimeClock(const tm* time,int ticksPerSecond):ticksPerSecond(ticksPerSecond){
	hour = time->tm_hour;
	min = time->tm_min;
	sec = time->tm_sec;

}

void RealTimeClock::gettime(tm *now){
	std::lock_guard<Imutex> lock(guard);
	now->tm_hour = hour;
	now->tm_min = min;
	now->tm_sec = sec;

}

void RealTimeClock::tick(){
	tickCounter++;
	if(tickCounter >= ticksPerSecond){
		tickCounter = 0;
		sec++;
		if(sec>=60){
			sec=0;
			min++;
			if(min>=60){
				min=0;
				hour++;
				if(hour>=24){
					hour=0;
				}
			}
		}
	}
}
